public class FactorialResponse
{
    public int Number { get; set; }
    public string Factorial { get; set; }
    public int DigitCount { get; set; }
    public string Error { get; set; }
}
