public class FactorialRequest
{
    public int Number { get; set; }
}
